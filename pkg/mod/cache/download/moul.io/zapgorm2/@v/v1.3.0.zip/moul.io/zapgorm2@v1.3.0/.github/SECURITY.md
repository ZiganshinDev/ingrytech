# Reporting security issues

I take security seriously. If you discover a security issue, please bring it to my attention right away!

### Reporting a Vulnerability

Please **DO NOT** file a public issue, instead send your report privately to security@moul.io.

Security reports are greatly appreciated and I will publicly thank you for it, although I keep your name confidential if you request it.
